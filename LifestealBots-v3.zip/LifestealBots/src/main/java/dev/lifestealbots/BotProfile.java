package dev.lifestealbots;

import org.bukkit.Location;
import java.util.UUID;

public class BotProfile {
    public enum ActivityState { SPAWN, WILD_RTP, AFK_ZONE }

    private final UUID uuid;
    private final String name;
    private final String prefix;
    private final String gearTier;
    private final String personality;
    private int hearts;
    private int entityId;
    private Location location;
    private boolean online;
    private ActivityState state = ActivityState.SPAWN;
    private double targetYaw;
    private boolean sprinting;

    public BotProfile(String name, String prefix, int hearts, String gearTier, String personality) {
        this.uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes());
        this.name = name;
        this.prefix = prefix;
        this.hearts = hearts;
        this.gearTier = gearTier;
        this.personality = personality;
    }

    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public String getPrefix() { return prefix; }
    public String getGearTier() { return gearTier; }
    public String getPersonality() { return personality; }
    public int getHearts() { return hearts; }
    public void setHearts(int hearts) { this.hearts = Math.max(1, Math.min(30, hearts)); }
    public int getEntityId() { return entityId; }
    public void setEntityId(int entityId) { this.entityId = entityId; }
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    public boolean isOnline() { return online; }
    public void setOnline(boolean online) { this.online = online; }
    public ActivityState getState() { return state; }
    public void setState(ActivityState state) { this.state = state; }
    public double getTargetYaw() { return targetYaw; }
    public void setTargetYaw(double targetYaw) { this.targetYaw = targetYaw; }
    public boolean isSprinting() { return sprinting; }
    public void setSprinting(boolean sprinting) { this.sprinting = sprinting; }
}
