package dev.lifestealbots;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes;
import com.github.retrooper.packetevents.protocol.player.Equipment;
import com.github.retrooper.packetevents.protocol.player.EquipmentSlot;
import com.github.retrooper.packetevents.protocol.player.GameMode;
import com.github.retrooper.packetevents.protocol.player.UserProfile;
import com.github.retrooper.packetevents.util.Vector3d;
import com.github.retrooper.packetevents.wrapper.play.server.*;
import io.github.retrooper.packetevents.util.SpigotConversionUtil;
import io.github.retrooper.packetevents.util.SpigotReflectionUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class PacketBotManager {
    private final LifestealBotsPlugin plugin;
    private final List<BotProfile> allProfiles = new ArrayList<>();
    private final Map<String, BotProfile> onlineBots = new LinkedHashMap<>();

    public PacketBotManager(LifestealBotsPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadProfiles() {
        despawnAll();
        allProfiles.clear();
        for (Map<?, ?> map : plugin.getConfig().getMapList("profiles")) {
            String name = String.valueOf(map.get("name"));
            String prefix = map.containsKey("prefix") ? String.valueOf(map.get("prefix")) : "&7";
            int hearts = map.containsKey("hearts") ? Integer.parseInt(String.valueOf(map.get("hearts"))) : 10;
            String gear = map.containsKey("gear") ? String.valueOf(map.get("gear")) : "DIAMOND";
            String personality = map.containsKey("personality") ? String.valueOf(map.get("personality")) : "friendly Indian SMP player";
            allProfiles.add(new BotProfile(name, prefix, hearts, gear, personality));
        }
    }

    public void connectBot(BotProfile bot, boolean announce) {
        if (bot.isOnline()) return;
        bot.setOnline(true);
        bot.setEntityId(SpigotReflectionUtil.generateEntityId());

        long visibleAtSpawn = onlineBots.values().stream()
                .filter(b -> b.getState() == BotProfile.ActivityState.SPAWN)
                .count();
        int maxAtSpawn = plugin.getConfig().getInt("bots.max-visible-at-spawn", 2);

        if (visibleAtSpawn < maxAtSpawn) {
            bot.setState(BotProfile.ActivityState.SPAWN);
        } else {
            bot.setState(ThreadLocalRandom.current().nextBoolean()
                    ? BotProfile.ActivityState.WILD_RTP
                    : BotProfile.ActivityState.AFK_ZONE);
        }

        World world = Bukkit.getWorlds().get(0);
        Location spawn = world.getSpawnLocation().clone().add(
                ThreadLocalRandom.current().nextDouble(-5, 5), 0, ThreadLocalRandom.current().nextDouble(-5, 5)
        );
        spawn.setY(world.getHighestBlockYAt(spawn) + 1);
        bot.setLocation(spawn);
        onlineBots.put(bot.getName().toLowerCase(), bot);

        for (Player viewer : Bukkit.getOnlinePlayers()) {
            sendTabAdd(viewer, bot);
            if (bot.getState() == BotProfile.ActivityState.SPAWN) {
                sendEntitySpawn(viewer, bot);
            }
        }

        if (announce) {
            String joinMsg = plugin.getConfig().getString("bots.join-message", "&8[&a+&8] &7%name% joined the game")
                    .replace("%name%", bot.getName());
            Bukkit.broadcast(LegacyComponentSerializer.legacyAmpersand().deserialize(joinMsg));
        }
    }

    public void disconnectBot(BotProfile bot, boolean announce) {
        if (!bot.isOnline()) return;
        bot.setOnline(false);
        onlineBots.remove(bot.getName().toLowerCase());

        for (Player viewer : Bukkit.getOnlinePlayers()) {
            var pm = PacketEvents.getAPI().getPlayerManager();
            pm.sendPacket(viewer, new WrapperPlayServerDestroyEntities(bot.getEntityId()));
            pm.sendPacket(viewer, new WrapperPlayServerPlayerInfoRemove(List.of(bot.getUuid())));
        }

        if (announce) {
            String quitMsg = plugin.getConfig().getString("bots.quit-message", "&8[&c-&8] &7%name% left the game")
                    .replace("%name%", bot.getName());
            Bukkit.broadcast(LegacyComponentSerializer.legacyAmpersand().deserialize(quitMsg));
        }
    }

    public void sendAllToViewer(Player viewer) {
        for (BotProfile bot : onlineBots.values()) {
            sendTabAdd(viewer, bot);
            if (bot.getState() == BotProfile.ActivityState.SPAWN) {
                sendEntitySpawn(viewer, bot);
            }
        }
    }

    private void sendTabAdd(Player viewer, BotProfile bot) {
        var pm = PacketEvents.getAPI().getPlayerManager();
        int latency = ThreadLocalRandom.current().nextInt(38, 132);
        Component display = LegacyComponentSerializer.legacyAmpersand().deserialize(bot.getPrefix() + bot.getName());
        UserProfile profile = new UserProfile(bot.getUuid(), bot.getName());
        var infoEntry = new WrapperPlayServerPlayerInfoUpdate.PlayerInfo(
                profile, true, latency, GameMode.SURVIVAL, display, null
        );
        pm.sendPacket(viewer, new WrapperPlayServerPlayerInfoUpdate(
                EnumSet.of(
                        WrapperPlayServerPlayerInfoUpdate.Action.ADD_PLAYER,
                        WrapperPlayServerPlayerInfoUpdate.Action.UPDATE_LISTED,
                        WrapperPlayServerPlayerInfoUpdate.Action.UPDATE_LATENCY,
                        WrapperPlayServerPlayerInfoUpdate.Action.UPDATE_DISPLAY_NAME
                ),
                infoEntry
        ));
    }

    private void sendEntitySpawn(Player viewer, BotProfile bot) {
        if (!plugin.getConfig().getBoolean("bots.physical-bodies", true)) return;
        Location loc = bot.getLocation();
        if (loc == null || !loc.getWorld().equals(viewer.getWorld())) return;

        var pm = PacketEvents.getAPI().getPlayerManager();
        pm.sendPacket(viewer, new WrapperPlayServerSpawnEntity(
                bot.getEntityId(),
                Optional.of(bot.getUuid()),
                EntityTypes.PLAYER,
                new Vector3d(loc.getX(), loc.getY(), loc.getZ()),
                loc.getPitch(), loc.getYaw(), loc.getYaw(), 0, Optional.empty()
        ));

        pm.sendPacket(viewer, new WrapperPlayServerEntityEquipment(bot.getEntityId(), buildGear(bot.getGearTier())));
    }

    private List<Equipment> buildGear(String tier) {
        return switch (tier.toUpperCase()) {
            case "NETHERITE" -> List.of(
                    new Equipment(EquipmentSlot.MAIN_HAND, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.NETHERITE_SWORD))),
                    new Equipment(EquipmentSlot.HELMET, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.NETHERITE_HELMET))),
                    new Equipment(EquipmentSlot.CHEST_PLATE, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.NETHERITE_CHESTPLATE))),
                    new Equipment(EquipmentSlot.LEGGINGS, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.DIAMOND_LEGGINGS))),
                    new Equipment(EquipmentSlot.BOOTS, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.NETHERITE_BOOTS)))
            );
            case "IRON" -> List.of(
                    new Equipment(EquipmentSlot.MAIN_HAND, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.IRON_SWORD))),
                    new Equipment(EquipmentSlot.HELMET, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.IRON_HELMET))),
                    new Equipment(EquipmentSlot.CHEST_PLATE, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.IRON_CHESTPLATE))),
                    new Equipment(EquipmentSlot.LEGGINGS, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.IRON_LEGGINGS))),
                    new Equipment(EquipmentSlot.BOOTS, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.IRON_BOOTS)))
            );
            default -> List.of(
                    new Equipment(EquipmentSlot.MAIN_HAND, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.DIAMOND_SWORD))),
                    new Equipment(EquipmentSlot.HELMET, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.DIAMOND_HELMET))),
                    new Equipment(EquipmentSlot.CHEST_PLATE, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.DIAMOND_CHESTPLATE))),
                    new Equipment(EquipmentSlot.LEGGINGS, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.DIAMOND_LEGGINGS))),
                    new Equipment(EquipmentSlot.BOOTS, SpigotConversionUtil.fromBukkitItemStack(new ItemStack(Material.DIAMOND_BOOTS)))
            );
        };
    }

    public void tickPhysicalMovement() {
        if (!plugin.getConfig().getBoolean("bots.physical-bodies", true)) return;
        double maxRadius = plugin.getConfig().getDouble("bots.spawn-radius", 28.0);

        for (BotProfile bot : onlineBots.values()) {
            if (bot.getState() != BotProfile.ActivityState.SPAWN) continue;
            Location loc = bot.getLocation();
            if (loc == null || loc.getWorld() == null) continue;

            if (ThreadLocalRandom.current().nextInt(2400) == 0) {
                bot.setState(BotProfile.ActivityState.WILD_RTP);
                for (Player viewer : Bukkit.getOnlinePlayers()) {
                    PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, new WrapperPlayServerDestroyEntities(bot.getEntityId()));
                }
                continue;
            }

            if (ThreadLocalRandom.current().nextInt(60) == 0) {
                Location spawn = loc.getWorld().getSpawnLocation();
                if (loc.distanceSquared(spawn) > maxRadius * maxRadius) {
                    Vector back = spawn.toVector().subtract(loc.toVector());
                    bot.setTargetYaw(Math.toDegrees(Math.atan2(-back.getX(), back.getZ())));
                } else {
                    bot.setTargetYaw(ThreadLocalRandom.current().nextDouble(-180, 180));
                }
                bot.setSprinting(ThreadLocalRandom.current().nextInt(3) == 0);
            }

            Player nearest = null;
            double bestDist = 49.0;
            for (Player p : loc.getWorld().getPlayers()) {
                double d = p.getLocation().distanceSquared(loc);
                if (d < bestDist) {
                    bestDist = d;
                    nearest = p;
                }
            }

            float yaw = (float) bot.getTargetYaw();
            float pitch = 0f;
            if (nearest != null) {
                Vector dir = nearest.getEyeLocation().toVector().subtract(loc.clone().add(0, 1.62, 0).toVector());
                yaw = (float) Math.toDegrees(Math.atan2(-dir.getX(), dir.getZ()));
                pitch = (float) Math.toDegrees(-Math.asin(dir.normalize().getY()));
            } else if (ThreadLocalRandom.current().nextInt(3) != 0) {
                double speed = bot.isSprinting() ? 0.23 : 0.13;
                double rad = Math.toRadians(yaw);
                double nx = loc.getX() - Math.sin(rad) * speed;
                double nz = loc.getZ() + Math.cos(rad) * speed;
                int topY = loc.getWorld().getHighestBlockYAt((int) Math.floor(nx), (int) Math.floor(nz));
                Block ground = loc.getWorld().getBlockAt((int) Math.floor(nx), topY, (int) Math.floor(nz));
                if (!ground.isLiquid() && Math.abs((topY + 1) - loc.getY()) <= 1.2) {
                    loc.setX(nx);
                    loc.setZ(nz);
                    loc.setY(topY + 1);
                } else {
                    bot.setTargetYaw(yaw + 120);
                }
            }

            loc.setYaw(yaw);
            loc.setPitch(pitch);

            for (Player viewer : loc.getWorld().getPlayers()) {
                if (viewer.getLocation().distanceSquared(loc) > 4096) continue;
                var pm = PacketEvents.getAPI().getPlayerManager();
                pm.sendPacket(viewer, new WrapperPlayServerEntityTeleport(
                        bot.getEntityId(), new Vector3d(loc.getX(), loc.getY(), loc.getZ()), yaw, pitch, true
                ));
                pm.sendPacket(viewer, new WrapperPlayServerEntityHeadLook(bot.getEntityId(), yaw));
            }
        }
    }

    public void balanceOnlinePopulation() {
        int target = plugin.getConfig().getInt("bots.target-online", 6);
        if (onlineBots.size() < target) {
            List<BotProfile> offline = allProfiles.stream().filter(b -> !b.isOnline()).toList();
            if (!offline.isEmpty()) {
                connectBot(offline.get(ThreadLocalRandom.current().nextInt(offline.size())), true);
            }
        } else if (onlineBots.size() > target && !onlineBots.isEmpty()) {
            List<BotProfile> online = new ArrayList<>(onlineBots.values());
            disconnectBot(online.get(ThreadLocalRandom.current().nextInt(online.size())), true);
        }
    }

    public void despawnAll() {
        for (BotProfile bot : new ArrayList<>(onlineBots.values())) {
            disconnectBot(bot, false);
        }
    }

    public Collection<BotProfile> getOnlineBots() { return onlineBots.values(); }
    public List<BotProfile> getAllProfiles() { return allProfiles; }
    public BotProfile getBot(String name) { return onlineBots.get(name.toLowerCase()); }
}
